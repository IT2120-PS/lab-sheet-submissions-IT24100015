#1
#set directory
setwd("C:\\Users\\it24100015\\Desktop\\Lab4")
#importing data set
branch_data <- read.table("Exercise.txt", header = TRUE, sep = " ")
print(branch_data)
#view the file in a separate window
fix(data)

#2
str(branch_data)
summary(branch_data)

#3
boxplot(branch_data$Sales_X1, main="Boxplot of Sales", horizontal=TRUE)

#4
# Five number summary
summary(branch_data$Advertising_X2)

# IQR calculation
IQR_Advertising <- IQR(branch_data$Advertising_X2)
print(IQR_Advertising)


#5
get.outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Apply function to 'years'
get.outliers(branch_data$Years_X3)



